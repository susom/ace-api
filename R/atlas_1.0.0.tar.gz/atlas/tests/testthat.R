library(testthat)
library(atlas)

test_check("atlas")
