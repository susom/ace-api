#' Returns the status of the ATLAS
#'
#' @param connection connection object returned from connect(url) function
#' @return data frame containing patient IDs and time intervals (optional)
#'
#' @examples
#' \donttest{atlas.status(atlas.connection('http://localhost:8080'))}
#'
#'
atlas.status <- function(connection) {
  response <- httr::POST(url = paste0(connection$url,'/status'))
  json_response <- httr::content(response, type="application/json")
  if (!is.null(json_response$errorMessage)) {
    stop(json_response$errorMessage)
  }

  return(json_response)
}
